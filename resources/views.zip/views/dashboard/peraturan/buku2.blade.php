@extends('dashboard.layouts.main')

@section('content')

<iframe src="{{ asset('pdf/Competition and Technical Rules – 2024 Edition.pdf') }}" style="width: 100%; height: 600px;"></iframe>

@endsection
