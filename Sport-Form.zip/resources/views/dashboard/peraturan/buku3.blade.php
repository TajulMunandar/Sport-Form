@extends('dashboard.layouts.main')

@section('content')

<iframe src="{{ asset('pdf/Instrumen Revisi.pdf') }}" style="width: 100%; height: 600px;"></iframe>

@endsection
